import React from "react";

const PriceCard = () => {
  return (
    <div>
      <h2>Price Card Component</h2>
    </div>
  );
};

export default PriceCard;
