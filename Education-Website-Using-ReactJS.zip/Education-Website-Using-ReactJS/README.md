Project Demo : https://scintillating-smakager-860376.netlify.app/  

Project Video : https://www.youtube.com/watch?v=KkQATIXBY5w&ab_channel=GorkCoder

![screencapture-scintillating-smakager-860376-netlify-app-2023-06-18-11_57_15](https://github.com/sunil9813/Education-Website-Using-ReactJS/assets/67497228/37450154-6e7a-45fd-9793-c731dcc56e2b)
